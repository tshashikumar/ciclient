<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * REST Server URL
 */
 
$config['rest_server'] = 'http://localhost/ciserver/';
/**
 * REST user api public and secret key
 */
$config['api_key'] = '9da0c9bd5f21b101c7bccd784ac6bb82'; //public key
$config['api_pkey'] = '9fbc0ffa06ef836173ee6095b3a2c3ca'; //secret key

/**
 * REST user api key identifier
 */
$config['api_name'] = 'X-API-KEY';
$config['bearer_name'] = 'x-bearer-key';
$config['time_name'] = 'x-time-key';

/*
 * For SSL
 */
$config['ssl_verify_peer'] = FALSE;
$config['ssl_cainfo'] = ''; // path of certificate  /certs/cert.pem

/**
 * For HTTP Authentication
 */
$config['enable_http_auth'] = FALSE;
$config['http_user'] = 'username';
$config['http_pass'] = 'password';
$config['http_auth'] = 'basic';
