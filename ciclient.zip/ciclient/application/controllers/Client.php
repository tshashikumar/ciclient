<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Controller {
    
    public function __construct() {
        parent::__construct();
        
    }
     public function index()
    {
       
        $response = $this->rest->get('login/users',array('id'=>'45435'));    
       // print_r($response);exit;   
        $this->output->set_output(json_encode($response));
    }

    public function userDelete()
    {
       
        $response = $this->rest->delete('login/users',array('id'=> 123));    
        print_r($response);exit;   
        print_r(json_encode($response));
    }
    
    public function userPost(){
       // $data = json_decode(file_get_contents('php://input'), true);
        $response = $this->rest->post('login/users',array('name'=>'454666611111','age' => 14));
        print_r($response);exit;
        print_r(json_encode($response));
    }
    public function userPut(){
       // $data = json_decode(file_get_contents('php://input'), true);
        $response = $this->rest->put('login/users',array('putval'=>'45466'));
        print_r($response);exit;
        print_r(json_encode($response));
    }
    
    public function exDelete(){
       // $data = json_decode(file_get_contents('php://input'), true);
        $response = $this->rest->delete('login/users',array('id'=>454666611111));
        print_r(json_encode($response));
    }

    
}
